def main(url):
	from bs4 import BeautifulSoup as bs
	import requests

	# opening our output file in append mode
	File = open("flipOutput.csv", "a")

	page = requests.get(url)
	soup = bs(page.content, 'html.parser')  # it gives us the visual representation of data

	# name of the product
	try:
		name=soup.find("span", class_="B_NuCI")
		name = name.text.replace("   "," ")
	except AttributeError:
		name = "NA"
	print("Name: ", name)
	File.write(f"{name},")

	# the discounted price
	try:
		discPrice = soup.find('div', class_="_30jeq3 _16Jk6d KqxjHe")
		discPrice = discPrice.text.strip()
	except AttributeError:
		discPrice = "NA"
	print("discPrice:",discPrice)
	File.write(f"{discPrice},")


	dP = []
	s = ""
	for i in discPrice:
		if i == "₹" or i == ",":
			continue
		else:
			s+=i
			dP.append(s)
		size = len(dP)-1
	try:
		discPrice = int(dP[size])
	except ValueError:
		discPrice = dP[size]

	# the original price
	try:
		ogPrice = soup.find('div', class_="_3I9_wc _2p6lqe KqxjHe")
		ogPrice = ogPrice.text
	except AttributeError: 
		ogPrice = "NA"
	print("original Price: ",ogPrice)

	oP = []
	s = ""
	for i in ogPrice:
		if i == "₹" or i == ",":
			continue
		else:
			s += i
			oP.append(s)
		size = len(oP) - 1
	origPrice = int(oP[size])

	# calculating the percentage discount:
	discount = ((origPrice - discPrice) / origPrice) * 100
	discount = round(discount, 1)
	discount = str(discount)+"%"
	print("discount:",discount)
	File.write(f"{discount},")

	# the average ratings(stars)
	try:
		stars = soup.find('div', class_="_2d4LTz")
		stars = stars.text+" out of 5 stars"
	except AttributeError:
		stars = "NA"
	print("ratings:",stars)
	File.write(f"{stars},")


	# the total ratings count(count)
	try:
		rating = soup.find('div', class_="row _2afbiS")
		split = rating.text.split(" ")
		final_rating = split[0]+" "+split[1]
	except AttributeError:
		final_rating = "NA"
	print("ratings count:",final_rating)
	File.write(f"{final_rating},")

	# Item in stock check
	try:
		stock = soup.find('div', class_="_1dVbu9")
		if stock is None:
			stock = "Availability: In Stock"
		else:
			stock = "Availability:", stock.text
	except AttributeError:
		stock = "NA"
		print(stock)
	print("Stock:",stock)
	File.write(f"{stock},\n")


	print("\n")

	# closing the file
	File.close()



if __name__ == '__main__':
	# opening our url file to access URLs
	file = open("url.txt", "r")

	# iterating over the urls
	for links in file.readlines():
		main(links)